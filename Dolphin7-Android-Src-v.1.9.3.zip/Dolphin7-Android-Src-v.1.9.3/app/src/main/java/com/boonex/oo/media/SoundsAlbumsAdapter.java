package com.boonex.oo.media;

import android.content.Context;

public class SoundsAlbumsAdapter extends MediaAlbumsAdapter {

	public SoundsAlbumsAdapter(Context context, Object[] aAlbums) {
		super(context, aAlbums);
	}
	
}
