package com.boonex.oo.media;

import android.content.Context;

public class VideosFilesAdapter extends MediaFilesAdapter {
	
	public VideosFilesAdapter(Context context, Object[] aFiles, String sUsername) {
		super(context, aFiles, sUsername);
	}
	
}
