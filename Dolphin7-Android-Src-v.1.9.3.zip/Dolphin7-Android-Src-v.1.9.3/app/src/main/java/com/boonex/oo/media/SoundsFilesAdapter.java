package com.boonex.oo.media;

import android.content.Context;

public class SoundsFilesAdapter extends MediaFilesAdapter {
	
	public SoundsFilesAdapter(Context context, Object[] aFiles, String sUsername) {
		super(context, aFiles, sUsername);
	}

}
