package com.boonex.oo.media;

import android.content.Context;

public class ImagesAlbumsAdapter extends MediaAlbumsAdapter {

	public ImagesAlbumsAdapter(Context context, Object[] aAlbums) {
		super(context, aAlbums);
	}
	
}
