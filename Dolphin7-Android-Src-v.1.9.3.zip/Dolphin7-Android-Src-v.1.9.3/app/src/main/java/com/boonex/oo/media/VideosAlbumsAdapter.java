package com.boonex.oo.media;

import android.content.Context;

public class VideosAlbumsAdapter extends MediaAlbumsAdapter {

	public VideosAlbumsAdapter(Context context, Object[] aAlbums) {
		super(context, aAlbums);
	}
	
}
